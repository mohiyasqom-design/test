# رحیق خبر — Marhale 5، Fix Round 2

## خلاصه
تنها تست باقی‌مانده (`CLI rejects password arguments safely and requires an interactive terminal`) در `tests/environment.test.ts` اصلاح شد. طبق «رویکرد ۱» بریف، فقط فایل تست تغییر کرد و `scripts/create-admin.ts` دست‌نخورده ماند (هش SHA-256 آن با manifest ورودی مطابق است).

## تأیید تحلیل ریشه‌ای
تحلیل ارائه‌شده در بریف درست بود و به‌صورت مستقل بازتولید شد. `parseArgs` بدون آرگومان `args` از `getMainArgs()` داخلی Node استفاده می‌کند و آن تابع در حالت `--eval` آفست برش را یک واحد جابه‌جا می‌کند. بنابراین `process.argv = [...]` داخل اسکریپت eval‌شده نمی‌تواند آرگومان‌های خط فرمان را شبیه‌سازی کند: نام جعلی اسکریپت (`create-admin.ts`) به‌عنوان یک positional دیده می‌شود، `allowPositionals: false` آن را رد می‌کند و کد پیش از رسیدن به چک `TTY_REQUIRED` وارد `catch` می‌شود.

بازتولید (Node v22.23.1، بدون نیاز به tsx چون `parseArgs` داخلی است):

| فراخوانی | نتیجه |
| --- | --- |
| `--eval` + `process.argv=[execPath,'create-admin.ts']` | `Unexpected argument 'create-admin.ts'` |
| فایل واقعی + `--email --display-name` | موفق، `positionals: []` |
| فایل واقعی + `--password PRIVATE_ARG` | `Unknown option '--password'` |
| فایل واقعی با `--import <loader>` | موفق (پیش‌بارگذاری `--import` آفست را جابه‌جا نمی‌کند) |

آخرین سطر مهم است: چون tsx با `--import` بار می‌شود، فراخوانی فایل واقعی همان رفتار درست را حفظ می‌کند.

## تغییر اعمال‌شده
در `tests/environment.test.ts`:

1. افزودن `fileURLToPath` از `node:url`.
2. افزودن helper جدید `createAdmin(args, overrides)` که خود فایل `scripts/create-admin.ts` را به‌عنوان یک فایل مجزا با `--import tsx` و آرگومان‌های واقعی خط فرمان اجرا می‌کند. این helper همان الگوی امنیتی `child()` را حفظ می‌کند: cwd موقت تا فایل `.env` واقعی توسعه‌دهنده خوانده نشود، `timeout: 20_000`، و `stdio` صریحاً pipe تا `stdin`/`stdout` قطعاً TTY نباشند.
3. بازنویسی تست CLI:
   - بخش `argument`: با `--email` معتبر به‌همراه `--password PRIVATE_ARG` → `Unknown option` → پیام `Invalid arguments`. بررسی نشت مقدار حالا هم روی `stderr` و هم روی `stdout` انجام می‌شود.
   - بخش `nonTty`: با آرگومان‌های کاملاً معتبر `--email` و `--display-name` تا تست واقعاً به چک TTY برسد و با چک آرگومان قاطی نشود.

`child()`، `envUrl`، دو تست fail-fast، تست کوکی production و تست redaction لاگر بایت‌به‌بایت بدون تغییر ماندند.

## راستی‌آزمایی انجام‌شده در این محیط
محیط اجرا اینترنت ندارد، پس `npm install`، `prisma generate` و اجرای رسمی تست‌ها ممکن نبود. به‌جای آن‌ها:

- `scripts/create-admin.ts` بدون هیچ تغییری با esbuild ترنسپایل و با شکل دقیق helper جدید اجرا شد (فقط وابستگی‌های نصب‌نشده stub شدند: `@prisma/client`، `src/config/env`، `auth.schema`، `password`).
  - `['--email','admin@example.com','--password','PRIVATE_ARG']` → status 1، پیام `Invalid arguments...`، بدون نشت `PRIVATE_ARG`.
  - `['--email','admin@example.com','--display-name','Test Admin']` → status 1، پیام `A secure interactive terminal is required...` که با `/interactive terminal/` مطابقت دارد.
  - کنترل با فراخوانی قدیمی `--eval` روی همان اسکریپت، خرابی گزارش‌شده را بازتولید کرد.
- بررسی syntax/transpilation برای ۶۳ فایل TypeScript: ۶۳ موفق، ۰ ناموفق.
- شمارش `test()`های سطح بالا در `tests/*.test.ts`: مجموع ۶۴، همسو با عدد مورد انتظار.
- diff کل بسته: فقط `backend/tests/environment.test.ts` تغییر کرده است.

جزئیات خروجی‌ها در `STATIC-CHECKS-ROUND-2.txt` است.

## آزمون‌های لازم در محیط مجهز
از پوشهٔ `backend` و با Node مطابق `engines`:

```sh
npm install
npm run typecheck
npm run build
npx tsx --test tests/environment.test.ts    # انتظار: ۵ pass
npm test                                     # انتظار: ۶۴ pass، ۰ fail
```

توجه: عدد ۶۴ در این محیط اجرا و تأیید نشده و فقط به‌صورت ایستا شمارش شده است. `npm test` فایل `tests/setup.ts` را preload می‌کند؛ اجرای مستقیم `npx tsx --test tests/*.test.ts` بدون این preload معادل فرمان رسمی پروژه نیست.

## Acceptance Criteria
- [x] فقط `tests/environment.test.ts` تغییر کرد.
- [x] `scripts/create-admin.ts` بدون تغییر (هش تأییدشده).
- [x] سه تست اصلاح‌شده در Fix Round 1 دست‌نخورده.
- [x] رویکرد ۱ بریف اعمال شد (فایل production دست‌نخورده).
- [~] پاس شدن ۵ تست فایل و ۶۴ تست کل: منطق به‌صورت مستقل تأیید شد، اما اجرای رسمی نیاز به `npm install` در محیط دارای شبکه دارد.
- [~] `npm run typecheck` و `npm run build`: قابل اجرا نبود؛ بررسی ترنسپایل با TypeScript 5.6.3 موجود انجام شد که جایگزین typecheck با ~5.9.2 نیست.

## محتوای بسته
- `backend/` — سورس اصلاح‌شده.
- `fix-round-2.patch` — دیف این دور (فقط برای بازبینی؛ backend از قبل اصلاح شده است).
- `STATIC-CHECKS-ROUND-2.txt` — خروجی بررسی‌ها.
- `BACKEND-FILES.sha256` — manifest معتبر این بسته (مسیرها نسبت به ریشهٔ بسته).
- `backend/FILES.sha256` و گزارش‌های قدیمی داخل `backend/`: سوابق ورودی‌اند و طبق محدودیت عدم تغییر سایر فایل‌ها دست‌نخورده ماندند، پس هش `tests/environment.test.ts` در آن‌ها مطابقت نخواهد داشت.
